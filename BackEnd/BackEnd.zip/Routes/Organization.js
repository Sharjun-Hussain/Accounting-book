const express = require('express');
const app = express();

app.route('/register')